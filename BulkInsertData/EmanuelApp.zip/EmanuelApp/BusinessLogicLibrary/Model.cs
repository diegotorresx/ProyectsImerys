﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogicLibrary
{
    public class Model
    {
        public string? GLAccountNumber { get; set; }
        public string? GLAccountName { get; set; }
        public string? AccountType { get; set; }
        public string? Mapping { get; set; }

    }
}
